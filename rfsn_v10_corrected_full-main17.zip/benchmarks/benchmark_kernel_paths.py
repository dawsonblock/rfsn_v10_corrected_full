#!/usr/bin/env python3
"""Benchmark sequential vs metal reconstruction paths for Main12."""

from __future__ import annotations

import argparse
import json
import math
import statistics
import time
from pathlib import Path

import pytest

mx = pytest.importorskip("mlx.core")

from rfsn_v10.kv_manager import RFSNTurboQuantKVManager


SHAPES = [
    (1, 4, 512, 64),
    (1, 8, 1024, 64),
    (1, 8, 2048, 64),
    (1, 32, 4096, 128),
]


def cosine_similarity(a: mx.array, b: mx.array) -> float:
    a_f = a.flatten().astype(mx.float32)
    b_f = b.flatten().astype(mx.float32)
    dot = mx.sum(a_f * b_f)
    norm = mx.sqrt(mx.sum(a_f * a_f)) * mx.sqrt(mx.sum(b_f * b_f))
    return (dot / mx.maximum(norm, mx.array(1e-8))).item()


def _make_manager(cache_dir: Path, mode: str) -> RFSNTurboQuantKVManager:
    if mode == "sequential_reference":
        return RFSNTurboQuantKVManager(
            cache_dir=str(cache_dir),
            k_bits=8,
            v_bits=3,
            use_wht=True,
            use_incoherent_signs=True,
            prefer_metal_kernels=False,
        )
    if mode == "metal_dequant_sign":
        return RFSNTurboQuantKVManager(
            cache_dir=str(cache_dir),
            k_bits=8,
            v_bits=3,
            use_wht=False,
            use_incoherent_signs=True,
            prefer_metal_kernels=True,
            strict_metal=False,
        )
    if mode == "metal_dequant":
        return RFSNTurboQuantKVManager(
            cache_dir=str(cache_dir),
            k_bits=8,
            v_bits=3,
            use_wht=False,
            use_incoherent_signs=False,
            prefer_metal_kernels=True,
            strict_metal=False,
        )
    if mode == "metal_dequant_wht":
        return RFSNTurboQuantKVManager(
            cache_dir=str(cache_dir),
            k_bits=8,
            v_bits=3,
            use_wht=True,
            use_incoherent_signs=False,
            prefer_metal_kernels=True,
            strict_metal=False,
        )
    if mode == "metal_dequant_wht_sign":
        return RFSNTurboQuantKVManager(
            cache_dir=str(cache_dir),
            k_bits=8,
            v_bits=3,
            use_wht=True,
            use_incoherent_signs=True,
            prefer_metal_kernels=True,
            strict_metal=False,
        )
    raise ValueError(f"Unsupported mode: {mode}")


def _median_retrieve_latency_ms(manager: RFSNTurboQuantKVManager, key: str, iterations: int) -> float:
    latencies = []
    for _ in range(iterations):
        t0 = time.perf_counter()
        rec = manager.retrieve(key, out_dtype=mx.float32)
        dt = (time.perf_counter() - t0) * 1000.0
        if rec is None:
            raise RuntimeError("Expected cache hit during retrieval benchmark")
        mx.eval(rec[0], rec[1])
        latencies.append(dt)
    return float(statistics.median(latencies))


def _latency_stats(latencies: list[float]) -> tuple[float, float, float]:
    if not latencies:
        return 0.0, 0.0, 0.0
    ordered = sorted(latencies)
    mean = float(statistics.fmean(ordered))
    p50 = float(statistics.median(ordered))
    p95_index = max(0, min(len(ordered) - 1, math.ceil(0.95 * len(ordered)) - 1))
    p95 = float(ordered[p95_index])
    return mean, p50, p95


def _bench_mode(shape: tuple[int, int, int, int], mode: str, iterations: int, base_dir: Path) -> dict:
    mx.random.seed(42)
    keys = mx.random.normal(shape)
    values = mx.random.normal(shape)

    key = f"mode={mode}|shape={shape}"
    mode_dir = base_dir / mode / ("x".join(str(v) for v in shape))
    mode_dir.mkdir(parents=True, exist_ok=True)

    manager = _make_manager(mode_dir, mode)
    manager.store(key, keys, values, token_count=shape[2])

    latencies = []
    for _ in range(iterations):
        t0 = time.perf_counter()
        rec = manager.retrieve(key, out_dtype=mx.float32)
        dt = (time.perf_counter() - t0) * 1000.0
        if rec is None:
            raise RuntimeError("Expected cache hit during retrieval benchmark")
        mx.eval(rec[0], rec[1])
        latencies.append(dt)
    latency_mean, latency_p50, latency_p95 = _latency_stats(latencies)
    k_out, v_out = manager.retrieve(key, out_dtype=mx.float32)
    mx.eval(k_out, v_out)

    cache = manager.active_caches[key]
    ref_k = manager._reconstruct_packed_dequant_wht(
        packed=cache.k_packed,
        scales=cache.k_scales,
        n_values=cache.k_n_values,
        shape=cache.shape,
        bits=cache.k_bits,
        seed=cache.seed,
        use_wht=cache.use_wht,
        use_incoherent_signs=cache.use_incoherent_signs,
        out_dtype=mx.float32,
    )
    ref_v = manager._reconstruct_packed_dequant_wht(
        packed=cache.v_packed,
        scales=cache.v_scales,
        n_values=cache.v_n_values,
        shape=cache.shape,
        bits=cache.v_bits,
        seed=cache.seed,
        use_wht=cache.use_wht,
        use_incoherent_signs=cache.use_incoherent_signs,
        out_dtype=mx.float32,
    )
    mx.eval(ref_k, ref_v)

    k_diff = mx.max(mx.abs(k_out - ref_k)).item()
    k_cosine = cosine_similarity(k_out, ref_k)
    v_diff = mx.max(mx.abs(v_out - ref_v)).item()
    v_cosine = cosine_similarity(v_out, ref_v)

    return {
        "shape": [int(v) for v in shape],
        "bits": 8,
        "mode": mode,
        "route": mode,
        "latency_ms_mean": latency_mean,
        "latency_ms_p50": latency_p50,
        "latency_ms_p95": latency_p95,
        "kv_reconstruction_kernel": manager.last_reconstruction_kernel,
        "fallback_used": manager.last_reconstruction_kernel == "metal_failed_fallback_reference",
        "key_cosine_vs_reference": float(k_cosine),
        "key_max_abs_diff_vs_reference": float(k_diff),
        "value_cosine_vs_reference": float(v_cosine),
        "value_max_abs_diff_vs_reference": float(v_diff),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark kernel reconstruction paths")
    parser.add_argument(
        "--out",
        default="artifacts/proof/main12/kernel_benchmark.json",
        help="Output JSON path",
    )
    parser.add_argument("--iterations", type=int, default=5)
    args = parser.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    modes = [
        "sequential_reference",
        "metal_dequant",
        "metal_dequant_wht",
        "metal_dequant_sign",
        "metal_dequant_wht_sign",
    ]

    runs: list[dict] = []
    reference_latencies: dict[str, float] = {}

    for shape in SHAPES:
        for mode in modes:
            row = _bench_mode(shape, mode, args.iterations, out_path.parent / "kernel_bench_tmp")
            runs.append(row)
            if mode == "sequential_reference":
                reference_latencies[str(tuple(shape))] = row["latency_ms_p50"]

    for row in runs:
        shape_key = str(tuple(row["shape"])) if isinstance(row.get("shape"), list) else str(row.get("shape"))
        ref_latency = reference_latencies.get(shape_key, row["latency_ms_p50"])
        computed_speedup = (
            float(ref_latency) / float(row["latency_ms_p50"])
            if float(row["latency_ms_p50"]) > 0
            else 0.0
        )

        # Validate K and V separately
        key_valid = (
            float(row["key_cosine_vs_reference"]) >= 0.999
            and float(row["key_max_abs_diff_vs_reference"]) <= 1e-3
        )
        value_valid = (
            float(row["value_cosine_vs_reference"]) >= 0.999
            and float(row["value_max_abs_diff_vs_reference"]) <= 1e-3
        )

        row["key_valid"] = key_valid
        row["value_valid"] = value_valid

        # Add route classification
        if row["mode"] in ["sequential_reference", "metal_dequant_wht_sign"]:
            row["route_class"] = "full_equivalent"
        else:
            row["route_class"] = "ablation"

        if row["mode"].startswith("metal_"):
            invalid = bool(row["fallback_used"]) or not key_valid or not value_valid
            row["status"] = "invalid" if invalid else "valid"
            row["speedup_vs_reference"] = None if invalid else float(computed_speedup)
        else:
            row["status"] = "valid"
            row["speedup_vs_reference"] = float(computed_speedup)

    payload = {
        "runs": runs,
        "summary": {
            "equivalence_pass_modes": [
                row["mode"]
                for row in runs
                if row["key_valid"] and row["value_valid"] and row.get("status") == "valid"
            ],
            "speedup_modes": [
                row["mode"]
                for row in runs
                if (
                    row["mode"].startswith("metal_")
                    and row["status"] == "valid"
                    and row["speedup_vs_reference"] > 1.0
                )
            ],
        },
    }

    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote kernel benchmark to {out_path}")


if __name__ == "__main__":
    main()
